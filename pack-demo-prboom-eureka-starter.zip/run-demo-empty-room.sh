prboom-plus -file map03-wall.wad 
